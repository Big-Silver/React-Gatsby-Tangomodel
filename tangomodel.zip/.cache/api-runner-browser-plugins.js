module.exports = [{
      plugin: require('/Volumes/WORK/project/React/tango/node_modules/gatsby-plugin-offline/gatsby-browser'),
      options: {"plugins":[]},
    },{
      plugin: require('/Volumes/WORK/project/React/tango/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
